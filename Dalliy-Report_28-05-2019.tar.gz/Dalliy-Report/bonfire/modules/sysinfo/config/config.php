<?php defined('BASEPATH') || exit('No direct script access allowed');

$config['module_config'] = array(
    'description' => 'Allows users to create translations for any language.',
    'name'        => 'lang:bf_menu_sysinfo',
    'author'      => 'Bonfire Team',
    'version'     => '0.7.3',
);

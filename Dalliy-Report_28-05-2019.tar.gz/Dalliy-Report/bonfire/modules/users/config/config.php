<?php defined('BASEPATH') || exit('No direct script access allowed');

$config['module_config'] = array(
    'author'      => 'Bonfire Team',
    'description' => 'Allows users to exist in Bonfire.',
    'name'        => 'lang:bf_menu_users',
    'version'     => '0.7.3',
    'weights'     => array(
        'settings' => 1,
    ),
);

<p>Thank you for registering on the <?php e($title) ?> web site</p>

<p>Your membership is under review by the site administrator and, if approved, you will be notified by email and then able to log in and begin using the site.</p>

Thank you.
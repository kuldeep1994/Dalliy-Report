
                    $('#start_time').datetimepicker({dateFormat: 'yy-mm-dd', timeFormat: 'hh:mm:ss'});
                    $('#end_time').datetimepicker({dateFormat: 'yy-mm-dd', timeFormat: 'hh:mm:ss'});
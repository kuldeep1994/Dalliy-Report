<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
//Translator: Sajjad Servatjoo <sajjad.servatjoo[at]gmail[dot]com>

$lang['set_allow_name_change_note']	= 'به کاربران اجازه داده شود که پس از ثبت نام ، نام نمایشی خود را تغییر دهند؟';
$lang['set_name_change_frequency']	= 'بار در هر ';
$lang['set_days']					= ' روز تغییر دهد';
<?php defined('BASEPATH') || exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'Speeds up creating the core code for new modules.',
	'author'		=> 'Bonfire Team',
	'name'			=> 'lang:bf_menu_code_builder',
);
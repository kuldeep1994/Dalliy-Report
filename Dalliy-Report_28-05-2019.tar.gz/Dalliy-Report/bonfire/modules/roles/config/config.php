<?php defined('BASEPATH') || exit('No direct script access allowed');

$config['module_config'] = array(
    'author'      => 'Bonfire Team',
    'description' => 'Provides Role-Based Access Control for users.',
    'name'        => 'lang:bf_menu_roles',
    'version'     => '0.7.3',
);
